/*
*@author Anene Terefe
*file 2_car.js
*/ 
"use strict"
Array.prototype.printTheName = (stringdisplay)=> {
    return stringdisplay;
  };
let arrTest=[];
console.log(arrTest.printTheName("Anna H. Smith"));  

